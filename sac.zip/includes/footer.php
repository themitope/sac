<section class="bg-white">
  <footer class="" style="overflow: hidden">
    <div class="">
      <div class="container">
        <div class="row">
          <div class="col-md-3 mt-5">
            <div class="mt-2">
              <h6>COMPANY</h6>
              <p class="footer_text mt-3"><a href="index">Home</a></p>
              <p class="footer_text"><a href="index">About us</a></p>
              <p class="footer_text"><a href="index">Shop</a></p>
              <p class="footer_text"><a href="index">Blog</a></p>
              <p class="footer_text"><a href="index">Contact Us</a></p>
            </div>
          </div>
          <div class="col-md-3 mt-5">
            <div class="mt-2">
              <h6>SERVICE</h6>
              <p class="footer_text mt-3"><a href="index">Support</a></p>
              <p class="footer_text"><a href="faq">FAQ</a></p>
              <p class="footer_text"><a href="terms_conditions">Terms & Conditions</a></p>
              <p class="footer_text"><a href="#">Live Chat</a></p>
              <p class="footer_text"><a href="privacy_policy">Privacy Policy</a></p>
            </div>
          </div>

          <div class="col-md-3 mt-5">
            <div class="mt-2">
              <h6>ORDERS & RETURNS</h6>
              <p class="footer_text mt-3"><a href="my_orders">Order</a></p>
              <p class="footer_text"><a href="my_orders">Status</a></p>
              <p class="footer_text"><a href="refund_policy">Refund Policy</a></p>
              <p class="footer_text"><a href="cart">Cart</a></p>
            </div>
          </div>

          <div class="col-md-3 mt-5">
            <div class="mt-2">
              <h6>PAYMENT ACCEPT</h6>
              <div class="row">
                <div class="col-md-3">
                  <img src="assets/images/master_card.png" class="img-fluid">
                </div>
                <div class="col-md-3">
                  <img src="assets/images/verve2.png" class="img-fluid">
                </div>
                <div class="col-md-3">
                  <img src="assets/images/visa-removebg-preview.png" class="img-fluid">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="mt-3 ">
        <div class="container">
          <p class="float-end mb-4" style="color: #A4A4A4;"> &copy; 2021 SAC Hairs All Rights Reserved</p>
        </div>
      </div>
    </div>
  </footer>
</section>