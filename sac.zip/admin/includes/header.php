<!DOCTYPE html>
<html>
<head>
	<title>SAC-Hairs</title>
	<link rel="stylesheet" type="text/css" href="../assets/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/style.css">
  <link rel="stylesheet" type="text/css" href="../assets/fontawesome/css/all.min.css">
  <link rel="stylesheet" type="text/css" href="../assets/js/toaster/build/toastr.min.css">
	<link rel="icon" type="image/png" href="../assets/images/sac_logo.png">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="color-scheme" content="dark light">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link rel="stylesheet" href="../bootstrap_step/dist/bootstrap-steps.css" />
  <link href="css/sb-admin-2.css" rel="stylesheet">
  <link href="css/select2.min.css" rel="stylesheet">
  <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>